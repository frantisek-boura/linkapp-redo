package link.app.backend.service;

public interface IImageCompressionService {

    byte[] compressImage(byte[] imageData);

}
